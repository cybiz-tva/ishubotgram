from .xpath_compile import xpath

def read_xpath(function_name, xpath_name):
    return xpath[function_name][xpath_name]