""" Custom Exceptions """


class InstaPyError(Exception):
    """ General error for InstaPy exceptions """

    pass
